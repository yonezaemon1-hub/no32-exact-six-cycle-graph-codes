# No.32 C6 — Exact Optimality v1.2 (independent-audit candidate)

**2026-10-22 / Ryutaro Yonezu / Yonezu Research Lab**

## The new claim

The exact maximum for binary graph codes on six labelled vertices whose pairwise differences are **not exactly Hamiltonian six-cycles** is

`D_{C6}(6) = 4096`.

The previously independently audited 64-word-per-component construction and 65-word upper bound left the alternatives 4096/4160. This candidate supplies the missing exclusion of a 65-word independent set in the 512-vertex Cayley component.

**NEW CERTIFICATE: independent verifier PASS internally, but not independently audited by Claude or a human. CLAIM STATUS: PRE-AUDIT. RELEASE: HOLD. NOVELTY: INCONCLUSIVE.**

## Contents

- `paper.pdf`, `paper.tex`: four-page English mathematical manuscript and source; no referee acceptance or established priority claim.
- `CERT_65_EXCLUSION_v1_2.json`: ninety integer Rayleigh PSD cuts and eleven integer equality multipliers; no hidden solver dependence.
- `verify_exact65.py`: standalone Python 3.12 standard-library certificate validator, independently reconstructing the C6 graph, the 10 pair orbits and 91 triple classes, all cut coefficients, Farkas arithmetic, actual 64-word control, and the a=64 non-contradiction check.
- `verification_run.log`: complete checked run log.
- `numeric_discovery_status.json`: cut-discovery history; **numerical observations are not proof**.
- `PRIOR_v1_1c_UNMODIFIED.zip`: previous source/audit material kept unchanged for traceability.
- `AUDIT_REQUEST.md`: instructions for a genuinely independent audit.
- `SHA256SUMS.txt`: checksums for all listed artifacts except this manifest itself.

## One command, offline

From this extracted directory (no installed libraries, no network, no GPU required):

```powershell
python verify_exact65.py
```

Look for:

```
PASS: independent real 64-code control and its 9 moment equalities
PASS cut 90/90
PASS a=64 negative-control gap ...
CERT_65 PASS_INDEPENDENT_EXACT; cuts= 90 gap= 65245054658776971334908126197187583410176
```

Do **not** treat an exception, partial output, early termination, or LP infeasibility status as proof. Exact positivity, and the validity of the moment and orbit formulation, are both essential.

## Rigorous model (short)

Let `a=65`, `V=F_2^9`, `F` the sixty forbidden C6 vectors. Translate a hypothetical independent set uniformly in V and relabel vertices uniformly under S6. With `rho=a/512`, set

- `d_u=E[X_0 X_u]/rho`;
- `t_{u,v}=E[X_0 X_u X_v]/rho`.

The 101 symmetrized variables lie in [0,1]. There are 11 exact identities: `sum_i |O_i|d_i = a`, eight extension identities `sum_j C_ij t_j = (a-2) d_i`, `d_0=1`, `d_5=0`. Every integer vector q produces valid cuts `q^T M^+ q >= 0`, `q^T M^- q >= 0`, with `M^+_{uv}=E[X_0 X_u X_v]/rho`, `M^-_{uv}=d_{u xor v}-M^+_{uv}`.

The JSON supplies nonnegative integer weights for ninety cut inequalities and eleven unrestricted integer equality multipliers, yielding `C dot z <= R`. Since `z` lies in [0,1]^101, `C dot z >= sum_i min(0,C_i)=B`. Exact integer reconstruction yields

`B-R = 65245054658776971334908126197187583410176 > 0`.

Therefore size 65 is impossible if the encoded identities and PSD inequalities are valid. A 64-word linear witness is checked independently by the verifier, giving exact optimum 64 for a component and 4096 globally.

## Audit/rights

1. Independently check the mathematical reasoning for every identity, orbit identification and PSD inequality. Do not merely rerun the supplied program.
2. Rebuild the arithmetic from the stored vectors and coefficients in a separate implementation (the included verifier is independent of the **discovery** code, but a different auditor should implement it again).
3. Test the 64-word witness and negative controls, and recompute hashes.
4. Check references and novelty against prior literature, including mathematically equivalent formulations.
5. Keep GitHub/Zenodo **HOLD** until proof and originality claims are appropriately qualified and audited.

All rights reserved. Code is provided for reproducibility and audit; no reuse license is granted.
