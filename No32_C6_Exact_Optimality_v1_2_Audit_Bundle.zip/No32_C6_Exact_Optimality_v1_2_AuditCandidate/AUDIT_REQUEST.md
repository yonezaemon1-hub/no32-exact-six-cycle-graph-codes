# Claude audit request — No.32 v1.2 new exact-65 exclusion

Please independently audit the enclosed four-page `paper.pdf` / `paper.tex` and `CERT_65_EXCLUSION_v1_2.json`.

**Target claim:** a 512-vertex component's independence number is **exactly 64** (not merely at most 65), hence `D_{C6}(6)=4096` for six labelled vertices and differences equal to an exact Hamiltonian 6-cycle. This is NOT a `contains C6` problem. **Do not presume PASS.**

Priority audit questions:

1. Rebuild all 60 forbidden cycle vectors from scratch; prove their span rank is 9; verify the 64-component decomposition and 64-word construction.
2. Derive from the random translation and S6 action the pair/triple moments and all eleven equations. Check that the anchor swap and S6 orbit closure give exactly 10 pair classes and **91** admissible triple classes without silently identifying inequivalent moment variables.
3. Check every entry of `M+` and `M-`, particularly diagonals, entries involving zero, and all forbidden differences. Confirm the Rayleigh cuts are genuinely PSD for *every* independent 65-set, not just the 64-word witness.
4. Using a **fresh implementation** independent of the supplied verifier, recompute all 90 integer quadratic-form coefficient vectors from the stored `q` vectors. Combine the stored nonnegative cut multipliers and 11 equality multipliers. Confirm the exact lower box bound and **strictly positive** contradiction gap `65245054658776971334908126197187583410176`.
5. Verify the same construction admits an actual 64-word independent set; check the certificate does **not** prove a false exclusion at `a=64`. Check malformed/altered certificates are rejected.
6. Audit `paper.tex` claims, references and the distinction between an exact 6-cycle and containing a C6. Check external literature for prior direct/equivalent finite results; mark NOVELTY=INCONCLUSIVE if not established.
7. Return separate PROOF / COMPUTATION / REFERENCES / NOVELTY / RELEASE findings. AI verification is not human refereeing. Do not publish on our behalf.

Reproduction: run `python verify_exact65.py` (Python 3.12, standard library, offline, current working directory arbitrary). Previous v1.1c material is included unchanged for the independently audited alpha<=65 step, although the new 65-exclusion proof is designed to stand alone.

**Known pre-audit status:** the discovery process returned numerical LP infeasibility; the certificate was rationalized, checked by a second independently authored Python implementation over arbitrary-precision integers, and tested against a real 64-word linear code. These steps remain subject to this independent audit.
